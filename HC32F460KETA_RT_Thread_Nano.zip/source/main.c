#include "hc32_ddl.h"
#include "rtthread.h"

#define  LED0_PORT        (PortC)
#define  LED0_PIN         (Pin09)
#define  LED0_TOGGLE()    (PORT_Toggle(LED0_PORT, LED0_PIN))

static struct rt_thread led_thread;
ALIGN(RT_ALIGN_SIZE)
static rt_uint8_t rt_led_thread_stack[1024];
static void led_thread_entry(void * para);
static rt_uint8_t led_thread_priority = 6;

/**
 *******************************************************************************
 ** \brief  Main function of template project
 **
 ** \param  None
 **
 ** \retval int32_t return value, if needed
 **
 ******************************************************************************/
int32_t main(void)
{
//    DDL_PrintfInit(DEBUG_USART_CH, DEBUG_USART_BAUDRATE, DebugUsartInit);
//    DDL_Printf("hc32 example. \r\n");
	    stc_port_init_t stcPortInit;
	
    MEM_ZERO_STRUCT(stcPortInit);

    stcPortInit.enPinMode = Pin_Mode_Out;
    stcPortInit.enExInt = Enable;
    stcPortInit.enPullUp = Enable;

    PORT_Init(LED0_PORT, LED0_PIN, &stcPortInit);
    	/* main thread */
	rt_thread_init(&led_thread,
					"led_thread",
					led_thread_entry,
					RT_NULL,
					&rt_led_thread_stack,
					sizeof(rt_led_thread_stack),
					led_thread_priority,
					1000);
	rt_thread_startup(&led_thread);
}


static void led_thread_entry(void * para)
{
  //  DDL_Printf("Entry %s. \r\n", __func__);
    while(1)
    {
        LED0_TOGGLE();
        rt_thread_mdelay(1000);
    }
}


